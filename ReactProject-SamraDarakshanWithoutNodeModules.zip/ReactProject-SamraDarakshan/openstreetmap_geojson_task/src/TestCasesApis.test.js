import Reat from 'react';
import TestCasesApis from './TestCasesApis';
import renderer from 'react-test-renderer';

it("Nominatim api Testing", async function (){ 
   const response = new TestCasesApis();
   //console.warn( await response.firstapi());
    var data = await response.firstapi();
   expect(data.features[0].bbox[0]).toEqual(67.1187434)
   expect(data.features[0].bbox[1]).toEqual(24.9102268)
   expect(data.features[0].bbox[2]).toEqual(67.1188434)
   expect(data.features[0].bbox[3]).toEqual(24.9103268)

} )

// it("open street api Testing", async function (){ 
//    const response = new TestCasesApis();
//   // console.warn( await response.secondapi());
//     var data = await response.secondapi();
//   //  console.log(data);
//    expect(data).toEqual("Long Life Bungalows");

//    // expect(data.features[0].properties.name).toEqual("Long Life Bungalows");
//    // expect(data.features[0].properties['addr:country']).toEqual("Pakistan");
//    // expect(data.features[0].properties['addr:city']).toEqual("Karachi");


// } )