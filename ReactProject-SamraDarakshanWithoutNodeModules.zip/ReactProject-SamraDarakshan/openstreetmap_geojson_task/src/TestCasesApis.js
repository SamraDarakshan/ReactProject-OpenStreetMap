class TestCasesApis {
    firstapi()

    {
    return fetch ("https://nominatim.openstreetmap.org/search?q=Pakistan+Karachi+Gulistan-e-Johar+Long Life Bungalows&format=geojson")
    .then((response)=>{
        return response.json();
    })
    }


secondapi()

{
return fetch ("https://www.openstreetmap.org/api/0.6/map?bbox=67.1187434,24.9102268,67.1188434,24.9103268&Content-Type=application/xml")
.then((response)=>{
    return response.json();
    console.log(response.json());
})
}
}

export default TestCasesApis;