import React from 'react';
import axios from 'axios';
import './TaskOpenStreet.css';
const osm2geojson = require('osm2geojson-lite');

class TaskOpenStreet extends React.Component {

// maintaining states
constructor(props) {
super(props);
this.state = {
    errorMessage:null,
};

this.state = {
country: null,
city: null,
area: null,
street: null,
errors: {
country: '',
city: '',
area: '',
street: ''
}
}

this.handleChange = this.handleChange.bind(this);
}

handleChange({ target }) {
this.setState({
[target.name]: target.value
});
}

// Get Nominatim api for bboox and pass bboxes in open street api
getApiData =()=> {

const  country  = this.state.country;
const  city  = this.state.city;
const  area  = this.state.area;
const  street  = this.state.street;


const path1 = 'https://nominatim.openstreetmap.org/search?q='+country+'+'+city+'+'+area+'+'+street+'&format=geojson'
console.log('PATH 1 '+path1)


if ((country === "" || country === null) && (city === "" || city === null) &&
    (area === "" || area === null) && (street === "" || street === null)){
    alert("Please Fill the Form!");
}
else{

axios.get(path1)
.then(response => {

    let min_lon=response.data.features[0].bbox[0];
    let  min_lat =response.data.features[0].bbox[1];
    let max_lon=response.data.features[0].bbox[2];
    let max_lat=response.data.features[0].bbox[3];

    console.log('Boundary Box parameters')
    console.log("min_lon : "+ min_lon);
    console.log("min_lat: "+min_lat);
    console.log("max_lon : "+ max_lon);
    console.log("max_lat: " +max_lat);
    console.log(response);

var myHeaders = new Headers();
myHeaders.append("Content-Type", "application/xml");
var requestOptions = {
method: 'GET',
headers: myHeaders,
redirect: 'follow'
};
const path ='https://www.openstreetmap.org/api/0.6/map?bbox='+min_lon+','+min_lat+','+max_lon+','+max_lat;
console.log("PATH 2 "+path)

fetch(path, requestOptions)
.then(response => {

return response.text()
})

.then(osmdata => { 


console.log('OSM '+(osmdata))    
let geojson = osm2geojson(osmdata, false);
        
        this.setState({ dataset: geojson, 
        country:geojson.features[0].properties['addr:country'],city: geojson.features[0].properties['addr:city'],
        place:geojson.features[0].properties['addr:place'],name: geojson.features[0].properties.name,
    }
            );
            let name = geojson.features[0].properties.name;
            let country = geojson.features[0].properties['addr:country'];
            let city = geojson.features[0].properties['addr:city'];
            let place = geojson.features[0].properties['addr:place'];

            console.log("name : "+ name);
            console.log("country: "+country);
            console.log("city : "+ city);
            console.log("place: " +place);
            console.log(response);

let geojsondata=JSON.stringify(geojson)
console.log('GEOJSON '+geojsondata)
}) 

.catch(error => {
this.setState({ errorMessage: error.message });

alert("Can not Find the boundary box, please re-enter fields!");
console.error('There was an error in open street API!', error);
});
})
        .catch(error => {
            
            alert("Can not Find the location, please fill the form!");
            console.error('There was an error in nominatim openstreetmap API!', error);
        });
    }
        
}

//Reset Form
resetForm = () => { 
document.getElementById("formId").reset();
}


//Rendering on html
render() {

const {dataset} =this.state;
const {country} = this.state;
const {city} = this.state;
const {place} = this.state;
const {name} = this.state;


return (

<div className="TaskOpenStreetStyle">

<h1>Open Street Map</h1>
<form  id="formId" name="myForm">
<input 
type="text" 
name="country" 
placeholder="Enter country here..." 
value={ this.state.country }
onChange={ this.handleChange } 
/>

<input 
type="text" 
name="city" 
placeholder="Enter city here..."
value={ this.state.city } 
onChange={ this.handleChange } 
/>

<input 
type="text" 
name="area" 
placeholder="Enter area here..." 
value={ this.state.area }
onChange={ this.handleChange } 
/>

<input 
type="text" 
name="street" 
placeholder="Enter street here..."
value={ this.state.street } 
onChange={ this.handleChange } 
/>

<br/>
<br/>
<button onClick =  {this.resetForm}> Reset Form </button>
</form>
<br/>

<button   onClick = {this.getApiData}> Show Location Details </button>
            
            <ul>
                {country}     <br/>
                {city}        <br/>
                {name}        <br/>
                {place}       <br/>
                
            </ul>

    <pre> {JSON.stringify(dataset,null,3)}</pre>
                                
</div>
);
}
}
export default TaskOpenStreet;



